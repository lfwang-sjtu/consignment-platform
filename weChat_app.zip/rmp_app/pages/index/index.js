//index.js
//获取应用实例
import showDetail from "../../modules/showDetail";
import showcDetail from "../../modules/showcDetail";
const app = getApp()

Page({
  data: {
    index_slides:[],
    indicator_dots:true,
    autoplay:true,
    interval:2000,
    duration:1000,
    nav_data:[],
    index_activity:[],
    index_block:[],
    isTap:false,
    isLoading:false,
    products:[
      {
        "name": "Stable Growth Fund",
        "description": "This fund aims to provide stable growth opportunities through a diversified investment portfolio for long-term returns.",
        "type": 1,
        "risk": 1,
        "rate": 0.08,
        "minInvest": 500.00,
        "term": 12,
        "manageFee": 0.015,
        "status": 1,
        "createDate": "2023-01-15",
        "belong": {"id": 1}
      },
      {
        "name": "High-Yield Bond Fund",
        "description": "This fund seeks to provide a high level of current income by investing primarily in high-yield corporate bonds.",
        "type": 1,
        "risk": 2,
        "rate": 0.12,
        "minInvest": 1000.00,
        "term": 24,
        "manageFee": 0.015,
        "status": 1,
        "createDate": "2022-11-20",
        "belong": {"id": 1}
      },
      {
        "name": "Technology Innovation Fund",
        "description": "This fund aims to capture opportunities in the technology sector by investing in innovative companies with strong growth potential.",
        "type": 1,
        "risk": 3,
        "rate": 0.15,
        "minInvest": 1000.00,
        "term": 36,
        "manageFee": 0.015,
        "status": 1,
        "createDate": "2023-03-10",
        "belong": {"id": 2}
      },
      {
        "name": "Global Equity Fund",
        "description": "This fund provides exposure to a diversified portfolio of global equities, seeking long-term capital appreciation.",
        "type": 1,
        "risk": 2,
        "rate": 0.07,
        "minInvest": 1000.00,
        "term": 24,
        "status": 1,
        "createDate": "2022-09-05",
        "belong": {"id": 2}
      }
    ]
  },

  getRiskClass(risk) {
    if (risk === 1) {
      return "low-risk";
    } else if (risk === 2) {
      return "medium-risk";
    } else if (risk === 3) {
      return "high-risk";
    }
  },
  getRiskLabel(risk) {
    if (risk === 1) {
      return "Low Risk";
    } else if (risk === 2) {
      return "Medium Risk";
    } else if (risk === 3) {
      return "High Risk";
    }
  },
  onLoad(){
    const index_slides=app.globalData.index_slides,
          nav_data=app.globalData.nav_data,
          index_activity=app.globalData.index_activity,
          index_block=app.globalData.index_block,
          sectionList=index_block.map((section)=>{
      return section.section;
    })
    console.log(sectionList);
    this.setData({
      index_slides,
      nav_data,
      index_activity,
      index_block,
    });
    
  },

  getRiskClass(risk) {
    if (risk === 1) {
      return "low-risk";
    } else if (risk === 2) {
      return "medium-risk";
    } else if (risk === 3) {
      return "high-risk";
    }
  },

   getRiskClass(risk) {
    if (risk === 1) {
      return "low-risk";
    } else if (risk === 2) {
      return "medium-risk";
    } else if (risk === 3) {
      return "high-risk";
    }
    return ""; // 防止没有匹配的情况下返回空字符串
  },

  // 根据风险级别返回对应的文本
  getRiskClass(risk) {
    if (risk == 1) {
      return "low-risk";
    } else if (risk == 2) {
      return "medium-risk";
    } else if (risk == 3) {
      return "high-risk";
    }
    return ""; // 防止没有匹配的情况下返回空字符串
  },

  // 根据风险级别返回对应的文本
  getRiskLabel(risk) {
    if (risk === 1) {
      return "Low Risk";
    } else if (risk === 2) {
      return "Medium Risk";
    } else if (risk === 3) {
      return "High Risk";
    }
    return "Unknown Risk"; // 防止没有匹配的情况下返回默认文本
  },

  onShow(e){
    this.setData({
      isTap:false
    });
  },
  //事件处理函数
  toSearch(e){
    this.setData({
      isTap:true
    });
    wx.navigateTo({
      url: "../search/search"
    })
  },
  // showDetail(e){
  //   const id=e.currentTarget.dataset.pid;
  //   console.log(id);
  // }
  showDetail,
  showcDetail
})


