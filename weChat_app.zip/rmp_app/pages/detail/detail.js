// pages/detail/detail.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    product: {}
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    const productData = {
      name: "Stable Growth Fund",
      description: "This fund aims to provide stable growth opportunities through a diversified investment portfolio for long-term returns.",
      type: 1,
      risk: 1,
      rate: 0.08,
      minInvest: 500.00,
      term: 12,
      manageFee: 0.015,
      status: 1,
      createDate: "2023-01-15"
    };

    this.setData({
      product: productData
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})